<template>
    <div>
        <v-app-bar>
            <v-btn>Home</v-btn>
        </v-app-bar>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>