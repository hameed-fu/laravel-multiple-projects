<template>
  <div class="home">
    <v-btn class="btn1" @click="getMessage">Call</v-btn>
        
    <v-container>
      <v-row>
        <div >{{ message}}</div>
      </v-row>
      <v-row>
        <form action="" @submit="check" method="post">
        <v-text-field v-model="word" type="text" ></v-text-field>
        </form>
      </v-row>
    </v-container>
  </div>
</template>

<script>

import axios from 'axios'
import VueEcho from 'vue-echo';
// import socket from 'socket.io-client';
import { io } from "socket.io-client";

const socket = io('http://127.0.0.1:3000',{reconnection: true,})

export default {
  data() {
    return {
      message:'',
      word:'',
    }
  },
  methods: {
    getMessage() {
      socket.emit("userChat", "hello from fornt end");
        // axios.get('http://127.0.0.1:8000/api/send',{
        // }).then(function(){
        //   console.log("called")
        //   // this.message = res.data
          
        // })
    },
    check(e){
      e.preventDefault();
      console.log(this.word)
      this.message = this.word
      socket.emit('userChat', this.word);
      this.word = ''

    }
  },
  mounted()
  {
    window.echo.channel('mychannel')
    .listen('MyEvent',function(data){
      console.log(data)
    })
  }
}
</script>


<style >
.btn1{
  text-align: center;
}
</style>
