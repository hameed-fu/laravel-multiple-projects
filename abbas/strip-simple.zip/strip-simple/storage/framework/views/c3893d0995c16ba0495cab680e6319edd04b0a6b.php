<!DOCTYPE html>
<html>
<head>
	<title>Payment</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <style type="text/css">
      
    </style>
</head>
<body>
  
<div class="container">  
    <h1>Information</h1>
    <div class="row">
        <table class="table table-hover">
            <tr>
            
                <th>#</th>
                <th>Title</th>
                <th>FName</th>
                <th>LName</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Amount</th>
                <th>Card Holder</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->title); ?></td>
                <td><?php echo e($row->fname); ?></td>
                <td><?php echo e($row->lname); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->contact); ?></td>
                <td><?php echo e($row->amount); ?></td>
                <td><?php echo e($row->card_holder); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </table>
    </div>
</div>
  
</body>
  

</html><?php /**PATH /Users/hameedullah/Documents/strip-simple/resources/views/account.blade.php ENDPATH**/ ?>