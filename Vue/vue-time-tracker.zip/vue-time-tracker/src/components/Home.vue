<template>
  <v-container>
    <v-row class="">

      <v-col cols="12" class="ml-4 mt-4">
        <h2 class=" font-weight-bold mb-3">
          Welcome to dashboard
        </h2>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" md="4" lg="12" sm="6" class="ml-4">
        data
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    name: 'Home',

    data: () => ({
      
    }),
  }
</script>
