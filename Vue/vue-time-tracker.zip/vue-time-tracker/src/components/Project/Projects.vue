<template>
  <v-container>
    <v-row class="">

      <v-col cols="12" class="ml-4 mt-4">
        <h2 class=" font-weight-bold mb-3">
          Projects
        </h2>
      </v-col>
    </v-row>
    <!-- button -->
    <v-row class="">
      <v-col cols="12" md="4" lg="12" sm="6" class="ml-4">
        <v-dialog
        v-model="dialog"
        persistent
        max-width="600px"
      >
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          color="primary"
          dark
          v-bind="attrs"
          v-on="on"
        >
          <v-icon>mdi-plus</v-icon>
        </v-btn>
        
      </template>
      <v-card>
        <v-card-title>
          <span class="text-h5">New Project</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-row>
              <v-col
                cols="12"
                sm="6"
                md="12"
              >
                <v-text-field
                  label="Project Name"
                  required
                ></v-text-field>
              </v-col>
              <v-col
                cols="12"
                sm="6"
                md="4"
              >
              </v-col>
             
            </v-row>

            <v-row>
              <v-col
                cols="12"
                sm="6"
              >
                 <v-text-field
                  label="Start date"
                  type="date"
                  required
                ></v-text-field>
              </v-col>
              <v-col
                cols="12"
                sm="6"
              >
                 <v-text-field
                  label="End date"
                  type="date"
                  required
                ></v-text-field>
              </v-col>
            </v-row>
          </v-container>
          <small>*indicates required field</small>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="blue darken-1"
            text
            @click="dialog = false"
          >
            Close
          </v-btn>
          <v-btn
            color="blue darken-1"
            text
            @click="dialog = false"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-dialog>
      </v-col>
    </v-row>
    <!-- button -->
    <!-- table -->
     <v-row>
        <v-col cols="12" class="ml-auto mt-4">
          <template>
          <v-data-table
          :headers="headers"
          :items="projects"
          :items-per-page="5"
          class="elevation-1"
          ></v-data-table>
          </template>
        </v-col>
     </v-row>
    <!-- table -->

  </v-container>
 
</template>

<script>
  export default {

    data () {
       return {
        dialog: false,
        headers: [
          {
            text: 'Porject',
            align: 'start',
            value: 'name',
          },
          { text: 'Calories', value: 'calories' },
          { text: 'Fat (g)', value: 'fat' },
          { text: 'Carbs (g)', value: 'carbs' },
          { text: 'Protein (g)', value: 'protein' },
          { text: 'Iron (%)', value: 'iron' },
        ],

        projects: [
          {
            name: 'project one',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: '1%',
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: '1%',
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: '7%',
          },
        ],
      }
    },
   
  }
</script>

<style lang="scss" scoped>

</style>