<template>
    <nav>
       
    <v-app-bar
        color="deep-purple"
        dark
        app
        >
        <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>

        <v-toolbar-title>Project</v-toolbar-title>
        <v-spacer></v-spacer>
        <v-spacer></v-spacer>

      
        <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
                
                <v-btn 
                    icon 
                    v-bind="attrs"
                    v-on="on"
                    >
                    <v-icon>mdi-logout</v-icon>
                </v-btn>
            </template>
            <span>Logout</span>
        </v-tooltip>
      
    </v-app-bar>
    <v-navigation-drawer
        v-model="drawer"
        app
        absolute
        fixed
        >
    <div>
        <v-list-item>
            <v-list-item-content>
                <div class="text-center">
                    <v-avatar color="primary" size="80" class="white--text" >User</v-avatar>
                    <h4>Hameed</h4>
                </div>
            </v-list-item-content>
        </v-list-item>
        <v-divider></v-divider>
    </div>
      <v-list
        nav
        dense
      >
      
        <v-list-item-group
          v-model="group"
          active-class="deep-purple--text text--accent-4"
         >
          <v-list-item to="/">
            <v-list-item-icon>
              <v-icon>mdi-home</v-icon>
            </v-list-item-icon>
            <v-list-item-title to="/">
                Home
            </v-list-item-title>
          </v-list-item>

          <v-list-item to="/projects">
            <v-list-item-icon>
              <v-icon>mdi-folder</v-icon>
            </v-list-item-icon>
                <v-list-item-title>
                    Project
                </v-list-item-title>
          </v-list-item>

          <v-list-item to="/tasks">
            <v-list-item-icon>
              <v-icon>mdi-alpha-t-circle</v-icon>
            </v-list-item-icon>
                <v-list-item-title>
                    Task
                </v-list-item-title>
          </v-list-item>

        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>

    </nav>
</template>

<script>
    export default {
    data: () => ({
      drawer: null,
      group: null,
    }),
  }

</script>

<style lang="scss" scoped>

</style>