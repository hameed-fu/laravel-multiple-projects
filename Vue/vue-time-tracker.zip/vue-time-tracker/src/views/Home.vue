<template>
  <Home />
</template>

<script>
  import Home from '../components/Home'

  export default {
    // name: 'Home',

    components: {
      Home,
    },
  }
</script>
