<template>
    <div>
        <Project />
    </div>
</template>

<script>
import Project from '../components/Project/Projects'
    export default {
        components:{
            Project
        }
    }
</script>

<style lang="scss" scoped>

</style>