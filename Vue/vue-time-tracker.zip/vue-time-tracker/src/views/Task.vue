<template>
  <div>
    <Task />
  </div>
</template>

<script>
import Task from '../components/Tasks/Task'
  export default {
    components:{
      Task
    }
  }
</script>

<style lang="scss" scoped>

</style>
